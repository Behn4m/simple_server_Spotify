
Image from variable and symbol
"""""""""""""""""""""""""""""""

.. lv_example:: widgets/img/lv_example_img_1
  :language: c


Image recoloring
""""""""""""""""

.. lv_example:: widgets/img/lv_example_img_2
  :language: c


Rotate and zoom
""""""""""""""""

.. lv_example:: widgets/img/lv_example_img_3
  :language: c

Image offset and styling
""""""""""""""""""""""""

.. lv_example:: widgets/img/lv_example_img_4
  :language: c


